<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'JvnerN$q%=Xh)KA@[$*QM@UU)<zkm#Cc4&QZ{R,Tj*U2G9;;kF;)mPQgFQfgKLJs');
define('SECURE_AUTH_KEY',  'F1Mll7bI+^E*E/FaFS _igBc}^q&O*rT/oi.:-H[,n:S2p1=ndN+f)^Zl`U-b8sy');
define('LOGGED_IN_KEY',    '}+ym;9S+n%g%12j)&GV-rBiy!k6Vul&C0 ]ah^p}H|0C~s(L6)^!pw--,[`B9.C-');
define('NONCE_KEY',        'wyiv4*:NJ)U#/YR8p&briKE JY$VC2RRH(%tJ}:~nL>|URkk;@o;4q5`|7w$)-4e');
define('AUTH_SALT',        'a}`:G~!RZ^t8AFdE+IX|+|bLd=}%>W!{L*+;6=g-&fR;YCZnS|vI>K3eE?c1d+qu');
define('SECURE_AUTH_SALT', '-]<Q-xjVLyGuwW5hQ]kipDVmEIrL,.c<ce-d]DP0$$x.WX2*([NrdbC7JeC:]{PM');
define('LOGGED_IN_SALT',   'q;e,|o:q_B.j+4H-zlFt,cG4Del_ler-wMaAq{Qmtt8TWMm{M-Z;~4/oUDbYsh9J');
define('NONCE_SALT',       'x7Y_dzI0yzZRUxho2skvutl2chB#fQXI|?VrSP`C(d/fs`JmQ{~3=5K+<*Kgv,Xk');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_portals';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

// Override Site URL Settings after moving site 
define( 'WP_SITEURL', 'http://localhost:8888' );

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

//define('RELOCATE',true);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
