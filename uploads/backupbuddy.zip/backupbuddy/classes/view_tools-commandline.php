<table class="widefat">
	<div id="pb_backupbuddy_advanced_details_div" style="display: none;">
		<textarea id="backupbuddy_details" cols="75" rows="6" style="width: 793px;"><?php _e('Backing up with BackupBuddy', 'it-l10n-backupbuddy');?> v<?php echo $this->_parent->plugin_info( 'version' ); ?>...</textarea>
	</div>
</table>
